<div class="modal fade" id="ajax-modal-view" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" tabindex="-1">

</div>
<div id="modal-loading-body" style="display: none;">
    <div class="modal-dialog modal-xs">
        <div class="modal-content">
            <div class="modal-body">
                <div class="text-center">
                    <div class="spinner-border " role="status">

                    </div>
                    <p class="d-block mt-2">در حال بارگذاری...</p>
                </div>
            </div>
        </div>
    </div>
</div>

</body>
<script src="<?= assets("js/bootstrap.bundle.min.js") ?>"></script>
<script src="<?= $mainAppEnqueue["js_url"] ?>"></script>
<?php footerFiles(); ?>

</html>