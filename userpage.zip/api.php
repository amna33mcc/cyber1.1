<?php 
header("Content-Type:application/json"); 
if (isset($_GET['username']) && $_GET['username']!="") { 
include('db.php'); 
$username = $_GET['username']; 
$result = mysqli_query($con, "SELECT * FROM `cp_users` WHERE username=$username"); 
$result2 = mysqli_query($con, "SELECT * FROM `cp_traffics` WHERE username=$username"); 
//if(mysqli_num_rows($result)>=0){ 
$row = mysqli_fetch_array($result); 
$start_date = $row['start_date']; 
$end_date = $row['end_date']; 
$password = $row['password']; 
$limit_users = $row['limit_users'];
$status = $row['status'];
 

$row2 = mysqli_fetch_array($result2);
$total = $row2['total']; 

response($username, $start_date, $end_date, $password, $total, $limit_users, $status ); 
mysqli_close($con); 
//}
//else{ 
//response(NULL, NULL, 200,"No Record Found"); 
//} 
}
else{ 
response(NULL, NULL, 400,"Invalusername Request"); 
} 

function response($username,$start_date,$end_date,$password, $total, $limit_users, $status){ 
$date_start = date('Y-m-d', $start_date);
$date_end = date('Y-m-d', $end_date);


$response['username'] = $username; 
$response['password'] = $password; 
if ($date_start=="1970-01-01")
$response['start_date'] = "no connect yet"; 
else
$response['start_date'] = $date_start; 
if ($date_start=="1970-01-01")
$response['end_date'] = "no connect yet";
 else
$response['end_date'] = $date_end; 
if ($status=="active")
$response['status'] = "<p style=\"color:#AAFF00\">فعال</p>";
else
	$response['status'] = "<p style=\"color:#D22B2B\">غیر فعال</p>";
$response['limit_users'] = $limit_users; 
$response['total'] = $total; 


$json_response = json_encode($response); 
echo $json_response; 
} 
?>

