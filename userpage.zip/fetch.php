<?php 
$username = $_POST['username']; 
$url = "http://ice.srv110.at/api.php?username='{$username}'";

$client = curl_init($url); 
curl_setopt($client,CURLOPT_RETURNTRANSFER,true); 
$response = curl_exec($client); 

$result = json_decode($response); 
if ($result->password!="") { 

echo "<head> <link rel=\"stylesheet\" href=\"https://fonts.googleapis.com/css?family=Lalezar\"><meta charset=\"UTF-8\"> <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0\"></head>"; 
echo "<body style=\"background-color:black;direction:rtl;font-family:'Lalezar';\">"; 
echo "<span style=\"background-color:black; color:#FFEA00;font-family: 'Lalezar';\">تاریخ امروز: &nbsp; </span>";
echo "<span style=\"background-color:black; color:#89CFF0;font-family: 'Lalezar';\" id=\"current_date\"></span>";
echo "<div><script>";
echo "date = new Date();";
echo "year = date.getFullYear();";
echo "month = date.getMonth() + 1;";
echo "day = date.getDate();";
echo "document.getElementById(\"current_date\").innerHTML = year + \"/\" + month + \"/\" + day;";
echo "</script>";
echo "</div>";
echo "<table style=\"style=\"color:#8dc63f;width:50%;\">"; 
echo "<tr style=\"border:1px solid black;\"><td style=\"color:#FFEA00;\">وضعیت:&nbsp;</td><td style=\"color:#8dc63f;font-size:25px\">$result->status</td></tr>";
echo "</table>"; 
echo "<center>  <label style=\"background-color:black; color:#FFEA00;font-family: 'Lalezar';\">----------------------------------------------------</label></center>";
echo "<table style=\"style=\"color:#8dc63f;width:50%;\">"; 
echo "<tr style=\"style=\"color:#8dc63f;\"><td style=\"color:#FFEA00;\">یوزرنیم:</td><td style=\"color:#89CFF0;\">$result->username</td></tr>"; 
//echo "<tr style=\"border:1px solid black;\"><td style=\"color:#FFEA00;\">پسورد:</td><td style=\"color:#89CFF0;\">$result->password</td></tr>"; 
echo "<tr style=\"border:1px solid black;\"><td style=\"color:#FFEA00; \">تاریخ اولین اتصال:  &nbsp;</td><td style=\"color:#89CFF0;\">$result->start_date</td></tr>"; 
echo "<tr style=\"border:1px solid black;\"><td style=\"color:#FFEA00;\">تاریخ پایان:</td><td style=\"color:#89CFF0;\">$result->end_date</td></tr>"; 
echo "<tr style=\"border:1px solid black;\"><td style=\"color:#FFEA00; \">تعداد کاربر مجاز:</td><td style=\"color:#89CFF0;\">$result->limit_users کاربر</td></tr>"; 
echo "<tr style=\"border:1px solid black;\"><td style=\"color:#FFEA00;\">حجم مصرفی:</td><td style=\"color:#89CFF0;\">$result->total مگابایت</td></tr>";   
echo "</table>"; 
echo "</body>"; 
}
else{ 
echo "<head> <link rel=\"stylesheet\" href=\"https://fonts.googleapis.com/css?family=Lalezar\"><meta charset=\"UTF-8\"> <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0\"></head>"; 
echo "<body style=\"color:#8dc63f;background-color:black;direction:rtl;font-family:'Lalezar';\">"; 
echo "<span style=\"color:#D22B2B\">اکانت شما به اتمام رسیده است </span><span>یا یوزرنیم اشتباه است</span>";
echo "</body>"; 
} 

?>
